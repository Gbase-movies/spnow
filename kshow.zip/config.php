<?php
// API base URL
$APIbaseURL = 'https://drama.dapi.me';

// Settings
$Title = 'Drama';
$FooterTitle = 'Drama';

// Menu
$RecentlyAddedSubTitle = 'Recently Added Sub';
$RecentlyAddedRawTitle = 'Recently Added Raw';
$MoviesTitle = 'Drama Movies';
$NewSeasonTitle = 'Kshow';
$PopularTitle = 'Popular Drama';
$OngoingTitle = 'Ongoing Series';

?>